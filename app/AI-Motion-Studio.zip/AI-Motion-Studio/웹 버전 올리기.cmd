@echo off
rem Rebuilds the share zip + web version and publishes it to GitHub Pages
rem (https://ssyeonss.github.io/ai-motion-studio/)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\make-share.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\make-web.ps1"
cd /d "%~dp0dist\web"
git add -A
git commit -q -m "Update web version"
git push -q
echo.
echo   Published: https://ssyeonss.github.io/ai-motion-studio/  (1~2 min to refresh)
echo.
pause
