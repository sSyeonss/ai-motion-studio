# Builds the web version (GitHub Pages) into dist\web:
#   /        landing page (site\index.html + site\media: intro video, slides)
#   /app/    the app itself — app files only, no bridge or launchers, plus the share zip for download
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$web = Join-Path $root "dist\web"
$app = Join-Path $web "app"
New-Item -ItemType Directory -Force -Path $web | Out-Null

# Clear previous build but keep the git repo (.git) used for publishing
Get-ChildItem -LiteralPath $web -Force | Where-Object { $_.Name -ne ".git" } | Remove-Item -Recurse -Force
New-Item -ItemType Directory -Force -Path $app | Out-Null

# Landing page
Copy-Item -Path (Join-Path $root "site\*") -Destination $web -Recurse -Force

# App
foreach ($f in @("app.js", "styles.css", "data")) {
  Copy-Item -LiteralPath (Join-Path $root $f) -Destination $app -Recurse -Force
}
# index.html + the getting-started page (matched by pattern: Windows PowerShell 5 misreads non-ASCII names in this file)
Get-ChildItem -LiteralPath $root -Filter "*.html" | Copy-Item -Destination $app -Force

$zip = Get-ChildItem -LiteralPath (Join-Path $root "dist") -Filter "AI-Motion-Studio-*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($zip) { Copy-Item -LiteralPath $zip.FullName -Destination (Join-Path $app "AI-Motion-Studio.zip") -Force }

# GitHub Pages: serve files as they are
New-Item -ItemType File -Force -Path (Join-Path $web ".nojekyll") | Out-Null

Write-Host "  OK  $web"
