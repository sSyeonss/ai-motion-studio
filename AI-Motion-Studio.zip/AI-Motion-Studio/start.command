#!/bin/bash
# AI Motion Studio 시작 (Mac): 연결 프로그램을 켜고 앱을 브라우저로 엽니다. 이 창은 켜 두세요.
# 처음에 열리지 않으면: 파일을 우클릭 → 열기, 또는 터미널에서  bash start.command
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js 가 필요해요. 열리는 페이지에서 LTS 버전을 설치한 뒤 다시 실행해 주세요."
  echo ""
  open "https://nodejs.org/ko"
  read -n 1 -s -r -p "아무 키나 누르면 닫혀요"
  exit 1
fi
node bridge/server.js
