@echo off
chcp 65001 >nul
rem AI Motion Studio 시작: 연결 프로그램을 켜고 앱을 브라우저로 엽니다 (이 창은 켜 두세요)
cd /d "%~dp0"
title AI Motion Studio
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js 가 필요해요. 열리는 페이지에서 LTS 버전을 설치한 뒤 이 파일을 다시 실행해 주세요.
  echo.
  start "" https://nodejs.org/ko
  pause
  exit /b 1
)
node bridge\server.js
pause
