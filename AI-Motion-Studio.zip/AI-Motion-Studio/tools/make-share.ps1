# Builds a shareable zip of the app (no personal data: projects, keys and logs live only in each browser).
# Output: dist\AI-Motion-Studio-YYYYMMDD.zip
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$stamp = Get-Date -Format "yyyyMMdd"
$name = "AI-Motion-Studio"
$dist = Join-Path $root "dist"
$stage = Join-Path ([IO.Path]::GetTempPath()) "$name-share"
$zip = Join-Path $dist "$name-$stamp.zip"

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $stage $name) | Out-Null
New-Item -ItemType Directory -Force -Path $dist | Out-Null

# Everything except build output, git data and local editor caches
$exclude = @("dist", ".git", "node_modules")
Get-ChildItem -LiteralPath $root -Force | Where-Object { $exclude -notcontains $_.Name -and $_.Extension -ne ".zip" } | ForEach-Object {
  Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $name) -Recurse -Force
}

# Mac launcher must keep LF line endings
$cmdFile = Join-Path (Join-Path $stage $name) "start.command"
if (Test-Path $cmdFile) {
  $text = [IO.File]::ReadAllText($cmdFile) -replace "`r`n", "`n"
  [IO.File]::WriteAllText($cmdFile, $text, (New-Object Text.UTF8Encoding $false))
}

if (Test-Path $zip) { Remove-Item $zip -Force }
# Zip with forward-slash paths (Compress-Archive on Windows PowerShell 5 writes backslashes, which break on Mac)
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$base = (Resolve-Path $stage).Path.TrimEnd('\') + '\'
$archive = [IO.Compression.ZipFile]::Open($zip, [IO.Compression.ZipArchiveMode]::Create)
try {
  Get-ChildItem -LiteralPath (Join-Path $stage $name) -Recurse -File -Force | ForEach-Object {
    $entry = $_.FullName.Substring($base.Length).Replace('\', '/')
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $_.FullName, $entry, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
  }
} finally { $archive.Dispose() }
Remove-Item $stage -Recurse -Force
$size = "{0:N1} MB" -f ((Get-Item $zip).Length / 1MB)
Write-Host ""
Write-Host "  OK  $zip  ($size)"
Write-Host ""
Start-Process explorer.exe "/select,`"$zip`""
