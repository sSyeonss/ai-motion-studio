# Builds the web version (GitHub Pages) into dist\web — app files only, no bridge or launchers.
# The share zip is copied in too so web visitors can download the full version.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$web = Join-Path $root "dist\web"
New-Item -ItemType Directory -Force -Path $web | Out-Null

# Clear previous build but keep the git repo (.git) used for publishing
Get-ChildItem -LiteralPath $web -Force | Where-Object { $_.Name -ne ".git" } | Remove-Item -Recurse -Force

foreach ($f in @("index.html", "app.js", "styles.css", "시작하기.html", "data")) {
  Copy-Item -LiteralPath (Join-Path $root $f) -Destination $web -Recurse -Force
}
# GitHub Pages: serve files as they are
New-Item -ItemType File -Force -Path (Join-Path $web ".nojekyll") | Out-Null

$zip = Get-ChildItem -LiteralPath (Join-Path $root "dist") -Filter "AI-Motion-Studio-*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($zip) { Copy-Item -LiteralPath $zip.FullName -Destination (Join-Path $web "AI-Motion-Studio.zip") -Force }

Write-Host "  OK  $web"
