@echo off
chcp 65001 >nul
rem 다른 사람에게 줄 압축 파일을 만듭니다 (내 프로젝트·키·작업 기록은 들어가지 않아요 — 모두 브라우저에만 있어요)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\make-share.ps1"
pause
