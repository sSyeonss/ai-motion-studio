// put-mcp.js — Claude Code 가 Higgsfield 업로드 URL 로 로컬 파일을 올릴 때 쓰는 아주 작은 MCP 서버 (stdio, 의존성 없음)
// 사용: node put-mcp.js <작업 폴더>   — 작업 폴더 밖의 파일은 올리지 않는다.
// 업로드는 Windows 기본 curl.exe 로 먼저, 안 되면 fetch 로 두 번 더 시도한다.
"use strict";
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFile } = require("child_process");

const DIR = path.resolve(process.argv[2] || ".");
const LOG = path.join(os.tmpdir(), "ai-motion-studio-bridge", "put.log");
const send = (msg) => process.stdout.write(JSON.stringify(msg) + "\n");
const log = (line) => { try { fs.appendFileSync(LOG, `${new Date().toISOString()} ${line}\n`); } catch { /* ignore */ } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const TOOL = {
  name: "put_file",
  description: "Upload one local job file to a presigned upload_url (HTTP PUT). Pass the upload_url EXACTLY as media_upload returned it (do not shorten, re-encode or retype it). Retries automatically. Then call media_confirm.",
  inputSchema: {
    type: "object",
    properties: {
      file: { type: "string", description: "File name inside the job folder (e.g. ref1.png)" },
      upload_url: { type: "string", description: "Presigned https upload_url from media_upload, copied exactly" },
      content_type: { type: "string", description: "MIME type, e.g. image/png" }
    },
    required: ["file", "upload_url"]
  }
};

// 오류의 실제 원인 (fetch failed 안쪽의 cause)
const why = (err) => [err.message, err.cause?.code, err.cause?.message].filter(Boolean).join(" | ");

function curlPut(full, url, contentType) {
  return new Promise((resolve, reject) => {
    const args = ["-sS", "--fail-with-body", "--retry", "2", "--max-time", "180", "-X", "PUT", "--upload-file", full, "-w", "%{http_code}", "-o", os.devNull];
    if (contentType) args.push("-H", `Content-Type: ${contentType}`);
    args.push(url);
    execFile("curl.exe", args, { windowsHide: true, timeout: 200000 }, (err, stdout, stderr) => {
      const code = String(stdout).trim().slice(-3);
      if (!err && /^2\d\d$/.test(code)) resolve(code);
      else reject(new Error(`curl ${code || ""} ${String(stderr || err?.message || "").trim()}`.slice(0, 300)));
    });
  });
}

async function putFile({ file, upload_url, content_type }) {
  const full = path.resolve(DIR, path.basename(String(file || "")));
  if (!full.startsWith(DIR + path.sep) || !fs.existsSync(full)) throw new Error(`file not found in job folder: ${file}`);
  let url;
  try { url = new URL(String(upload_url || "").trim()); } catch { throw new Error("upload_url is not a valid URL — pass it exactly as media_upload returned it"); }
  if (url.protocol !== "https:") throw new Error("upload_url must be https");
  const body = fs.readFileSync(full);
  const headers = content_type ? { "Content-Type": content_type } : {};
  const tag = `${path.basename(full)} ${body.length}B -> ${url.host} (url ${String(upload_url).length} chars)`;
  // 1순위 curl.exe — 이 PC 에서 Node fetch 가 upload.higgsfield.ai 에 연결 시간 초과(UND_ERR_CONNECT_TIMEOUT)를 자주 내서
  try {
    const code = await curlPut(full, url.href, content_type);
    log(`OK curl ${tag}`);
    return `HTTP ${code} — uploaded ${path.basename(full)} (${body.length} bytes)`;
  } catch (err) {
    log(`curl failed ${tag}: ${err.message}`);
  }
  let last = "";
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const res = await fetch(url, { method: "PUT", body, headers, signal: AbortSignal.timeout(180000) });
      if (res.ok) { log(`OK fetch#${attempt} ${tag}`); return `HTTP ${res.status} — uploaded ${path.basename(full)} (${body.length} bytes)`; }
      last = `HTTP ${res.status} ${(await res.text().catch(() => "")).slice(0, 200)}`;
      if (res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) break; // 주소·권한 문제는 다시 해도 같다
    } catch (err) {
      last = why(err);
    }
    log(`retry fetch#${attempt} ${tag}: ${last}`);
    await sleep(800 * attempt);
  }
  log(`FAIL ${tag}: ${last}`);
  throw new Error(`upload failed for ${path.basename(full)} to ${url.host}: ${last}`);
}

async function handle(msg) {
  const { id, method, params } = msg;
  if (method === "initialize") {
    return send({ jsonrpc: "2.0", id, result: { protocolVersion: params?.protocolVersion || "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "ams", version: "1.1.0" } } });
  }
  if (method === "tools/list") return send({ jsonrpc: "2.0", id, result: { tools: [TOOL] } });
  if (method === "tools/call") {
    try {
      if (params?.name !== "put_file") throw new Error(`unknown tool ${params?.name}`);
      const text = await putFile(params.arguments || {});
      return send({ jsonrpc: "2.0", id, result: { content: [{ type: "text", text }] } });
    } catch (err) {
      return send({ jsonrpc: "2.0", id, result: { content: [{ type: "text", text: String(err.message || err) }], isError: true } });
    }
  }
  if (method === "ping") return send({ jsonrpc: "2.0", id, result: {} });
  if (id !== undefined) send({ jsonrpc: "2.0", id, error: { code: -32601, message: `Method not found: ${method}` } });
}

let buf = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buf += chunk;
  let i;
  while ((i = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    try { handle(JSON.parse(line)); } catch { /* 잘못된 줄은 무시 */ }
  }
});
