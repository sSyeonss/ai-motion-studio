// server.js — AI Motion Studio 로컬 연결 프로그램
// - 앱을 http://127.0.0.1:8790 으로 열어 준다.
// - 글 작업: 이 PC 에 로그인된 '내 구독'을 그대로 쓴다 (API 키 불필요). 설치돼 있는 것만 켜진다.
//     Claude Code (`claude -p`) · ChatGPT = Codex CLI (`codex exec`) · Gemini CLI (`gemini -p`, 베타)
// - 이미지·영상: Claude Code 가 Higgsfield 커넥터로 업로드 → 생성 → 대기를 하고, 결과 파일을 내려받아 앱에 넘긴다.
// 의존성 없음. 실행: node bridge/server.js  (Windows: start.cmd · Mac: start.command)
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn, execFile } = require("child_process");

const PORT = Number(process.env.AMS_PORT) || 8790;
const HOST = "127.0.0.1";
const ROOT = path.resolve(__dirname, "..");
const WORK = path.join(os.tmpdir(), "ai-motion-studio-bridge");
const ALLOWED_ORIGINS = new Set([`http://${HOST}:${PORT}`, `http://localhost:${PORT}`]);
const MAX_BODY = 300 * 1024 * 1024;
const MAX_PARALLEL = 3;
fs.mkdirSync(WORK, { recursive: true });

// ── Claude Code 찾기 ─────────────────────────────
function findClaude() {
  const appdata = process.env.APPDATA || "";
  const home = os.homedir();
  const candidates = [
    path.join(appdata, "npm", "node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe"),
    path.join(home, ".local", "bin", "claude.exe"),
    path.join(home, ".local", "bin", "claude"),
    path.join(home, ".claude", "local", "claude"),
    "/opt/homebrew/bin/claude", "/usr/local/bin/claude"
  ];
  return candidates.find((p) => fs.existsSync(p)) || "claude";
}
const CLAUDE = findClaude();
const IS_WIN = process.platform === "win32";

// npm 으로 설치한 CLI(Codex·Gemini)는 셸 없이 node 로 바로 실행한다 (긴 프롬프트·따옴표가 안전하게 넘어가게)
const npmRoots = [
  process.env.APPDATA && path.join(process.env.APPDATA, "npm", "node_modules"),
  path.join(os.homedir(), ".npm-global", "lib", "node_modules"),
  "/opt/homebrew/lib/node_modules", "/usr/local/lib/node_modules", "/usr/lib/node_modules"
].filter(Boolean);
function findNodeCli(pkg, bin) {
  for (const root of npmRoots) {
    try {
      const dir = path.join(root, ...pkg.split("/"));
      const meta = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8"));
      const rel = typeof meta.bin === "string" ? meta.bin : meta.bin?.[bin];
      if (rel && fs.existsSync(path.join(dir, rel))) return path.join(dir, rel);
    } catch { /* 다음 위치 */ }
  }
  return null;
}
// npm 전역 폴더가 다른 곳이면 'npm root -g' 로 한 번 더 찾는다
execFile(IS_WIN ? "npm.cmd" : "npm", ["root", "-g"], { windowsHide: true, timeout: 20000, shell: IS_WIN }, (err, out) => {
  const root = String(out || "").trim();
  if (!err && root && !npmRoots.includes(root)) { npmRoots.unshift(root); checkStatus(); }
});

const status = { claude: null, higgsfield: null, codex: null, gemini: null, checkedAt: 0 };
const cli = { codex: null, gemini: null };

function checkStatus() {
  execFile(CLAUDE, ["--version"], { windowsHide: true, timeout: 30000 }, (err, out) => { status.claude = err ? null : String(out).trim(); });
  execFile(CLAUDE, ["mcp", "list"], { windowsHide: true, timeout: 90000 }, (err, out) => {
    status.higgsfield = !err && /Higgsfield:.*Connected/i.test(String(out));
    status.checkedAt = Date.now();
  });
  cli.codex = findNodeCli("@openai/codex", "codex");
  cli.gemini = findNodeCli("@google/gemini-cli", "gemini");
  for (const name of ["codex", "gemini"]) {
    if (!cli[name]) { status[name] = null; continue; }
    execFile(process.execPath, [cli[name], "--version"], { windowsHide: true, timeout: 30000 }, (err, out) => { status[name] = err ? null : String(out).trim().split("\n").pop(); });
  }
}

// ── 동시 실행 제한 ───────────────────────────────
let running = 0;
const waiting = [];
async function slot(fn) {
  if (running >= MAX_PARALLEL) await new Promise((r) => waiting.push(r));
  running++;
  try { return await fn(); } finally { running--; waiting.shift()?.(); }
}

// claude -p 실행 → JSON 결과
function runClaude(args, input, { cwd, timeoutMs, env = {} }) {
  return slot(() => new Promise((resolve, reject) => {
    const child = spawn(CLAUDE, args, { cwd, windowsHide: true, env: { ...process.env, CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1", ...env } });
    let out = "", err = "";
    const timer = setTimeout(() => { child.kill(); reject(new Error("Claude Code 응답 시간이 초과됐어요")); }, timeoutMs);
    child.stdout.on("data", (d) => (out += d));
    child.stderr.on("data", (d) => (err += d));
    child.on("error", (e) => { clearTimeout(timer); reject(new Error(`Claude Code 를 실행하지 못했어요: ${e.message}`)); });
    child.on("close", (code) => {
      clearTimeout(timer);
      let json;
      try { json = JSON.parse(out); } catch {
        return reject(new Error(`Claude Code 오류 (code ${code}): ${(err || out).trim().slice(0, 400) || "출력 없음"}`));
      }
      if (json.is_error) return reject(new Error(String(json.result || json.api_error_status || "Claude Code 오류").slice(0, 400)));
      resolve(json);
    });
    child.stdin.end(input);
  }));
}

// 구조화 출력 꺼내기 (--json-schema 사용 시 structured_output, 아니면 result 텍스트의 JSON)
function structured(json) {
  if (json.structured_output && typeof json.structured_output === "object") return json.structured_output;
  const text = String(json.result || "");
  const s = text.indexOf("{"), e = text.lastIndexOf("}");
  if (s < 0 || e <= s) throw new Error("Claude Code 가 JSON 을 돌려주지 않았어요");
  return JSON.parse(text.slice(s, e + 1));
}

// 사용량 요약 (구독 한도 감 잡기용)
const usageOf = (json) => ({
  seconds: Math.round((json.duration_ms || json.duration_api_ms || 0) / 1000),
  tokens: (json.usage?.input_tokens || 0) + (json.usage?.cache_creation_input_tokens || 0) + (json.usage?.cache_read_input_tokens || 0) + (json.usage?.output_tokens || 0),
  cacheRead: json.usage?.cache_read_input_tokens || 0,
  turns: json.num_turns || 0
});

// 작업 기록 (실패 원인 찾기용) — %TEMP%\ai-motion-studio-bridge\bridge.log
function logJob(entry) {
  try { fs.appendFileSync(path.join(WORK, "bridge.log"), `${new Date().toISOString()} ${JSON.stringify(entry)}\n`); } catch { /* ignore */ }
  const failed = (entry.items || []).filter((x) => x.status !== "completed" && x.status !== "dry_run");
  if (failed.length) console.log(`[Higgsfield] ${entry.model}: 실패 ${failed.length}건 — ${failed.map((x) => x.error).filter(Boolean).join(" / ").slice(0, 300)}`);
}

function newJobDir() {
  const id = crypto.randomUUID();
  const dir = path.join(WORK, id);
  fs.mkdirSync(dir, { recursive: true });
  return { id, dir };
}

const EXT = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "video/mp4": "mp4", "video/quicktime": "mov", "video/webm": "webm" };
function writeFiles(dir, files) {
  return (files || []).map((f, i) => {
    const type = String(f.type || "image/png");
    const name = `ref${i + 1}.${EXT[type] || "png"}`;
    fs.writeFileSync(path.join(dir, name), Buffer.from(String(f.data || ""), "base64"));
    return { name, type, key: f.key ?? i };
  });
}

// ── 글 작업: 가벼운 claude -p ────────────────────
async function handleClaude(body) {
  const { dir } = newJobDir();
  const files = writeFiles(dir, body.images);
  let prompt = String(body.prompt || "");
  if (files.length) prompt += `\n\n[첨부 이미지] 이 폴더의 다음 파일을 Read 도구로 열어 보고 참고하세요: ${files.map((f) => f.name).join(", ")}`;
  const args = [
    "-p", "--output-format", "json",
    "--json-schema", JSON.stringify(body.schema || { type: "object" }),
    "--system-prompt", String(body.system || ""),
    "--tools", files.length ? "Read" : "",
    "--restricted", "--strict-mcp-config", "--no-session-persistence",
    "--permission-prompts", "none",
    "--model", String(body.model || "opus"),
    "--effort", String(body.effort || "medium")
  ];
  try {
    const json = await runClaude(args, prompt, { cwd: dir, timeoutMs: 10 * 60 * 1000 });
    return { data: structured(json), usage: usageOf(json) };
  } finally {
    fs.rm(dir, { recursive: true, force: true }, () => {});
  }
}

// ── 글 작업: 다른 구독 CLI ───────────────────────
// 실행 → 종료 코드·출력 (공통)
function runCli(file, args, input, { cwd, timeoutMs, label }) {
  return slot(() => new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [file, ...args], { cwd, windowsHide: true, env: process.env });
    let out = "", err = "";
    const timer = setTimeout(() => { child.kill(); reject(new Error(`${label} 응답 시간이 초과됐어요`)); }, timeoutMs);
    child.stdout.on("data", (d) => (out += d));
    child.stderr.on("data", (d) => (err += d));
    child.on("error", (e) => { clearTimeout(timer); reject(new Error(`${label} 를 실행하지 못했어요: ${e.message}`)); });
    child.on("close", (code) => { clearTimeout(timer); resolve({ code, out, err }); });
    child.stdin.end(input);
  }));
}

// 텍스트에서 JSON 꺼내기 (코드 블록·앞뒤 설명이 붙어도)
function pickJson(text) {
  const t = String(text || "").replace(/```(?:json)?/gi, "");
  const s = t.indexOf("{"), e = t.lastIndexOf("}");
  if (s < 0 || e <= s) throw new Error("JSON 을 돌려주지 않았어요");
  return JSON.parse(t.slice(s, e + 1));
}

// OpenAI 구조화 출력(strict)은 모든 속성이 required 여야 한다 → 선택 속성은 null 도 받게 바꾼다
function strictify(schema) {
  if (!schema || typeof schema !== "object") return schema;
  const s = Array.isArray(schema) ? schema.map(strictify) : { ...schema };
  if (s.type === "object" && s.properties) {
    const req = new Set(s.required || []);
    s.properties = Object.fromEntries(Object.entries(s.properties).map(([k, v]) => {
      const p = strictify(v);
      if (!req.has(k) && p.type && !Array.isArray(p.type)) p.type = [p.type, "null"];
      return [k, p];
    }));
    s.required = Object.keys(s.properties);
    s.additionalProperties = false;
  }
  if (s.items) s.items = strictify(s.items);
  return s;
}
const dropNulls = (v) => (Array.isArray(v) ? v.map(dropNulls) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).filter(([, x]) => x !== null).map(([k, x]) => [k, dropNulls(x)])) : v);

// ChatGPT 구독: codex exec (읽기 전용 샌드박스, 최종 답을 스키마로)
async function handleCodex(body) {
  if (!cli.codex) throw new Error("Codex CLI 가 설치돼 있지 않아요 (npm i -g @openai/codex → codex login)");
  const { dir } = newJobDir();
  const files = writeFiles(dir, body.images);
  try {
    fs.writeFileSync(path.join(dir, "schema.json"), JSON.stringify(strictify(body.schema || { type: "object", properties: {} })));
    const outFile = path.join(dir, "answer.json");
    const args = ["exec", "--skip-git-repo-check", "--sandbox", "read-only", "--color", "never",
      "--output-schema", path.join(dir, "schema.json"), "-o", outFile,
      "-c", `model_reasoning_effort="${body.effort === "high" ? "high" : "medium"}"`,
      ...(body.model ? ["-m", String(body.model)] : []),
      ...files.flatMap((f) => ["-i", path.join(dir, f.name)]), "-"];
    const prompt = `[지침]\n${body.system || ""}\n\n[요청]\n${body.prompt || ""}\n\n도구나 파일을 쓰지 말고, 지정된 JSON 스키마에 맞는 최종 답만 돌려주세요.`;
    const r = await runCli(cli.codex, args, prompt, { cwd: dir, timeoutMs: 10 * 60 * 1000, label: "Codex(ChatGPT)" });
    const text = fs.existsSync(outFile) ? fs.readFileSync(outFile, "utf8") : r.out;
    if (r.code !== 0 && !fs.existsSync(outFile)) throw new Error(`Codex 오류: ${(r.err || r.out).trim().split("\n").slice(-3).join(" ").slice(0, 300) || `code ${r.code}`}${/login|auth/i.test(r.err) ? " — 터미널에서 codex login 을 해 주세요" : ""}`);
    return { data: dropNulls(pickJson(text)) };
  } finally {
    fs.rm(dir, { recursive: true, force: true }, () => {});
  }
}

// Gemini 구독(구글 계정): gemini CLI (베타 — 스키마 옵션이 없어 프롬프트로 JSON 을 요청)
async function handleGemini(body) {
  if (!cli.gemini) throw new Error("Gemini CLI 가 설치돼 있지 않아요 (npm i -g @google/gemini-cli → gemini 로 로그인)");
  const { dir } = newJobDir();
  const files = writeFiles(dir, body.images);
  try {
    const prompt = `[지침]\n${body.system || ""}\n\n[요청]\n${body.prompt || ""}` +
      `${files.length ? `\n\n[첨부 이미지]\n${files.map((f) => `@${f.name}`).join(" ")}` : ""}` +
      `\n\n[출력 형식] 아래 JSON 스키마에 맞는 JSON 하나만 출력하세요. 설명·코드 블록 없이.\n${JSON.stringify(body.schema || {})}`;
    const args = ["-p", "위 입력의 [요청]을 수행하고 [출력 형식]대로 JSON 만 출력하세요.", "--output-format", "json", ...(body.model ? ["-m", String(body.model)] : [])];
    const r = await runCli(cli.gemini, args, prompt, { cwd: dir, timeoutMs: 10 * 60 * 1000, label: "Gemini CLI" });
    if (r.code !== 0 && !r.out.trim()) throw new Error(`Gemini CLI 오류: ${r.err.trim().split("\n").slice(-3).join(" ").slice(0, 300) || `code ${r.code}`}`);
    let text = r.out;
    try { const j = JSON.parse(r.out); text = j.response ?? j.result ?? r.out; } catch { /* 그냥 글 */ }
    return { data: pickJson(text) };
  } finally {
    fs.rm(dir, { recursive: true, force: true }, () => {});
  }
}

// ── 이미지·영상: Claude Code + Higgsfield 커넥터 ──
const HF = "mcp__claude_ai_Higgsfield__";
const HF_NEEDED = ["media_upload", "media_confirm", "generate_image", "generate_image_batch", "generate_video", "generate_video_batch", "jobs_wait"];
const HF_TOOLS = HF_NEEDED.map((t) => HF + t);
// 커넥터의 나머지 도구는 금지해서 모델 문맥에서 빼 버린다 (도구 설명이 매 단계 실려 사용량이 크게 늘기 때문)
const HF_ALL = ["ads_studio_add_product", "ads_studio_cancel_run", "ads_studio_create_brand", "ads_studio_generate", "ads_studio_get_brand", "ads_studio_get_product",
  "ads_studio_get_run", "ads_studio_list_brands", "ads_studio_list_products", "ads_studio_list_runs", "ads_studio_quote", "ads_studio_update_product",
  "ai_influencer_generate", "ai_influencer_get_options", "ai_influencer_get_settings", "ai_influencer_list_presets", "ai_influencer_prepare", "animation_actions",
  "apps_describe", "apps_invoke", "apps_search", "archive_project", "attach_project_asset", "balance", "build_ai_influencer", "cancel_project_publication_review",
  "cancel_trial_auto_renewal", "confirm_project_publication_review", "copy_project_asset", "create_folder", "create_project", "create_voice",
  "create_voice_from_confirmed_audio", "create_website", "delete_folder", "delete_project", "deploy_website", "dubbing", "execute_preset", "generate_3d",
  "generate_audio", "generate_audio_batch", "get_explainer_presets", "get_folder", "get_katana_config", "get_playable_game_publication", "get_preferences",
  "get_preset_instructions", "get_presets", "get_project", "get_project_asset_prompt", "get_project_asset_source", "get_project_publication",
  "get_workflow_bundle_file", "get_workflow_instructions", "job_display", "list_folders", "list_project_assets", "list_projects", "list_voices",
  "list_website_categories", "list_websites", "list_workspaces", "manage_reference_elements", "media_import_url", "media_upload_widget", "models_explore",
  "motion_control", "move_folder", "move_project_asset", "outpaint_image", "participate_in_contest", "publish_playable_game", "publish_project",
  "publish_website", "reframe", "register_katana_result", "register_what_if_result", "remove_background", "remove_project_asset", "rename_folder",
  "rename_website", "resolve_explainer_preset", "resolve_project_assets", "sandbox_exec", "save_project_publication_preview",
  "scene_builder_3d_create_project", "scene_builder_3d_generate_angles", "scene_builder_3d_generate_video", "scene_builder_3d_get_artifact",
  "scene_builder_3d_get_blend", "scene_builder_3d_get_generation", "scene_builder_3d_get_glb", "scene_builder_3d_get_operation",
  "scene_builder_3d_get_project", "scene_builder_3d_import_asset", "scene_builder_3d_list_generations", "scene_builder_3d_list_projects",
  "scene_builder_3d_query_python", "scene_builder_3d_run_python", "scene_builder_3d_search_assets", "scene_builder_3d_show_scene", "search_folders",
  "select_workspace", "shorts_studio_create", "shorts_studio_create_preset", "shorts_studio_list_presets", "shorts_studio_list_sessions",
  "shorts_studio_status", "show_characters", "show_credit_reset", "show_generation_by_ids", "show_generations", "show_katana_result",
  "show_marketing_studio_generations", "show_marketing_studio_v2", "show_medias", "show_plans_and_credits", "show_reference_elements", "show_result",
  "tiktok_accounts", "tiktok_connect", "tiktok_music_trending", "tiktok_music_tune", "tiktok_prepare_publish", "tiktok_publish_status", "tiktok_reconnect",
  "transactions", "unarchive_project", "unpublish_project", "update_preferences", "update_project", "update_project_publication", "upscale_image",
  "upscale_video", "video_analysis_create", "video_analysis_jobs", "video_analysis_status", "virality_predictor", "voice_change", "website_db",
  "website_repo_access", "website_secrets", "website_status"];
const HF_DENY = [...HF_ALL.filter((t) => !HF_NEEDED.includes(t)).map((t) => HF + t), "mcp__claude_ai_Claude_Docs", "mcp__higgsfield-use-blender"];

const HF_SYSTEM = `You are a headless media-generation runner for a local app. Follow the JOB exactly using tools. Never ask questions, never explain, never call any tool not listed below.
Steps:
1. If JOB.files is not empty: call ${HF}media_upload once with files=[{filename, content_type}] for every JOB.files entry. For each returned upload_url call mcp__ams__put_file(file=<that filename>, upload_url=<url>, content_type=<type>). Then call ${HF}media_confirm(media_ids=[all ids], type=<"image" or "video" per file>). If an upload fails, report every item as failed with the error.
2. If JOB.dry_run is true: call ${HF}generate_image (or generate_video for kind=video) for the FIRST item only with params + get_cost:true, then return its cost in "cost" and every item status "dry_run". Do not submit anything.
3. Otherwise, first call ${HF}generate_image (or generate_video) for the FIRST item with its params + get_cost:true to learn the price per item (this does not submit). Then submit every JOB.items entry with ${HF}generate_image_batch (kind=image) or ${HF}generate_video_batch (kind=video), max 12 per call, index = item.index, count 1. Params = item.params plus model=JOB.model, use_unlim=JOB.use_unlim, and medias built from item.refs: each ref filename → {value: its media_id, role: item.roles[ref] }. Omit folder_id. Do not call get_preferences or create projects.
4. Call ${HF}jobs_wait(timeout_seconds 15) on the submitted jobs repeatedly until all are terminal (stop after 60 waits).
5. Return the JSON: one entry per item with index, status ("completed"/"failed"/"dry_run"), job_id, result urls, and error text if failed.
   Also per item: "credits" = credits actually charged for that item as shown in the submit/job responses; if not shown, the get_cost price (for video, scale by that item's duration if the quote was for a different duration); 0 if it ran in unlimited/free mode or failed without charge; -1 if unknown. "unlim" = true if it ran in unlimited/free mode.
If a tool returns a recovery_tool, call it as instructed. If a tool returns unlim_choice, retry once with use_unlim=JOB.use_unlim.
If an item is rejected because unlimited/free-trial mode is unsupported or unavailable, resubmit that item once with use_unlim=false (the user allowed credits as the fallback). Put any rejection or failure reason from the tool into that item's error text.`;

const HF_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["items", "cost"],
  properties: {
    cost: { type: "string" },
    items: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["index", "status", "job_id", "urls", "error", "credits", "unlim"],
        properties: {
          index: { type: "integer" }, status: { type: "string" }, job_id: { type: "string" }, urls: { type: "array", items: { type: "string" } }, error: { type: "string" },
          credits: { type: "number" }, unlim: { type: "boolean" }
        }
      }
    }
  }
};

// 결과 파일 받기: Node fetch 가 Higgsfield 쪽 서버에 연결 시간 초과를 낼 때가 있어 curl.exe 로 한 번 더 받는다
async function download(url, file) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(120000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    fs.writeFileSync(file, Buffer.from(await res.arrayBuffer()));
    return res.headers.get("content-type") || "";
  } catch (err) {
    const type = await new Promise((resolve, reject) => {
      execFile("curl.exe", ["-sSL", "--fail", "--retry", "2", "--max-time", "300", "-o", file, "-w", "%{content_type}", url], { windowsHide: true, timeout: 320000 },
        (e, stdout, stderr) => (e ? reject(new Error(`결과 파일을 받지 못했어요 (${err.message} / ${String(stderr || e.message).trim().slice(0, 200)})`)) : resolve(String(stdout).trim())));
    });
    logJob({ download: "curl", url: new URL(url).host, after: err.message });
    return type;
  }
}

async function handleHiggsfield(body) {
  const kind = body.kind === "video" ? "video" : "image";
  const { id, dir } = newJobDir();
  const files = writeFiles(dir, body.files);
  const nameOf = new Map(files.map((f) => [String(f.key), f.name]));
  const job = {
    kind,
    model: String(body.model || (kind === "video" ? "seedance_2_5" : "gpt_image_2_5")),
    use_unlim: !!body.useUnlim,
    dry_run: !!body.dryRun,
    files: files.map((f) => ({ filename: f.name, content_type: f.type })),
    items: (body.items || []).map((it, i) => ({
      index: i,
      params: it.params || {},
      refs: (it.refs || []).map((r) => nameOf.get(String(r.key))).filter(Boolean),
      roles: Object.fromEntries((it.refs || []).map((r) => [nameOf.get(String(r.key)), r.role]).filter(([n]) => n))
    }))
  };
  const mcpConfig = JSON.stringify({ mcpServers: { ams: { command: process.execPath, args: [path.join(__dirname, "put-mcp.js"), dir] } } });
  const args = [
    "-p", "--output-format", "json",
    "--json-schema", JSON.stringify(HF_SCHEMA),
    "--system-prompt", HF_SYSTEM,
    "--tools", "",
    "--mcp-config", mcpConfig,
    "--allowedTools", [...HF_TOOLS, "mcp__ams__put_file"].join(","),
    "--disallowedTools", HF_DENY.join(","),
    "--permission-prompts", "none",
    "--no-session-persistence",
    "--model", "sonnet",
    "--effort", "low"
  ];
  // Higgsfield 커넥터는 도구가 아주 많아서, 도구 설명을 필요할 때만 불러오게 한다 (사용량 절약)
  const json = await runClaude(args, `JOB:\n${JSON.stringify(job, null, 1)}`, { cwd: dir, timeoutMs: (kind === "video" ? 40 : 15) * 60 * 1000, env: { ENABLE_TOOL_SEARCH: "true" } });
  const out = structured(json);
  logJob({ kind, model: job.model, unlim: job.use_unlim, dry: job.dry_run, items: (out.items || []).map((x) => ({ i: x.index, status: x.status, error: x.error, urls: (x.urls || []).length, credits: x.credits, unlim: x.unlim })), cost: out.cost, usage: usageOf(json) });
  const items = [];
  for (const it of out.items || []) {
    // 크레딧: 이 항목에 쓴 크레딧 (모르면 null) — 앱의 '작업 현황'에 단계별로 쌓인다
    const credits = Number.isFinite(it.credits) && it.credits >= 0 ? it.credits : null;
    const entry = { index: it.index, status: it.status, error: it.error || "", files: [], credits, unlim: !!it.unlim };
    for (const [n, url] of (it.urls || []).entries()) {
      try {
        const base = `out_${it.index}_${n}`;
        const type = await download(url, path.join(dir, base));
        const ext = EXT[type.split(";")[0]] || (kind === "video" ? "mp4" : "png");
        fs.renameSync(path.join(dir, base), path.join(dir, `${base}.${ext}`));
        entry.files.push(`/bridge/file/${id}/${base}.${ext}`);
      } catch (err) { entry.error = String(err.message || err); }
    }
    items.push(entry);
  }
  // 올린 레퍼런스는 지우고 결과만 잠시 남긴다 (1시간 뒤 정리)
  files.forEach((f) => fs.rm(path.join(dir, f.name), { force: true }, () => {}));
  setTimeout(() => fs.rm(dir, { recursive: true, force: true }, () => {}), 60 * 60 * 1000);
  return { cost: out.cost || "", items, usage: usageOf(json) };
}

// ── HTTP ─────────────────────────────────────────
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".svg": "image/svg+xml" };

function sendJson(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}

function sendFile(res, file) {
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(data);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > MAX_BODY) { reject(new Error("요청이 너무 커요")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}")); } catch { reject(new Error("JSON 형식이 아니에요")); } });
    req.on("error", reject);
  });
}

// 다른 웹사이트가 이 프로그램을 부르지 못하게: 같은 주소에서 온, 표시 헤더가 붙은 요청만 받는다 (CORS 헤더는 주지 않는다)
function trusted(req) {
  const origin = req.headers.origin;
  return req.headers["x-ams"] === "1" && (!origin || ALLOWED_ORIGINS.has(origin)) && /^(127\.0\.0\.1|localhost):\d+$/.test(req.headers.host || "");
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  try {
    if (url.pathname.startsWith("/bridge/")) {
      if (!trusted(req)) return sendJson(res, 403, { error: "허용되지 않은 요청이에요" });
      if (req.method === "GET" && url.pathname === "/bridge/health") {
        if (Date.now() - status.checkedAt > 5 * 60 * 1000) checkStatus();
        return sendJson(res, 200, { ok: true, claude: status.claude, higgsfield: status.higgsfield, codex: status.codex, gemini: status.gemini, platform: process.platform });
      }
      // 글 작업: 고른 구독으로 (claude | codex | gemini)
      if (req.method === "POST" && url.pathname === "/bridge/text") {
        const body = await readBody(req);
        const run = { codex: handleCodex, gemini: handleGemini }[body.provider] || handleClaude;
        return sendJson(res, 200, await run(body));
      }
      const fileMatch = url.pathname.match(/^\/bridge\/file\/([0-9a-f-]{36})\/(out_\d+_\d+\.[a-z0-9]+)$/);
      if (req.method === "GET" && fileMatch) return sendFile(res, path.join(WORK, fileMatch[1], fileMatch[2]));
      if (req.method === "POST" && url.pathname === "/bridge/claude") return sendJson(res, 200, await handleClaude(await readBody(req)));
      if (req.method === "POST" && url.pathname === "/bridge/higgsfield") return sendJson(res, 200, await handleHiggsfield(await readBody(req)));
      return sendJson(res, 404, { error: "없는 경로예요" });
    }
    if (req.method !== "GET") { res.writeHead(405); return res.end(); }
    // 앱 정적 파일 (bridge 폴더와 숨김 파일은 내주지 않는다)
    const rel = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
    const file = path.resolve(ROOT, "." + rel);
    if (!file.startsWith(ROOT + path.sep) || file.startsWith(path.join(ROOT, "bridge")) || /[\\/]\./.test(rel)) { res.writeHead(404); return res.end(); }
    return sendFile(res, file);
  } catch (err) {
    console.error(err);
    logJob({ path: url.pathname, error: String(err.message || err) });
    return sendJson(res, 500, { error: String(err.message || err) });
  }
});

server.listen(PORT, HOST, () => {
  const appUrl = `http://${HOST}:${PORT}/`;
  console.log(`AI Motion Studio 연결 프로그램이 켜졌어요: ${appUrl}`);
  console.log(`Claude Code: ${CLAUDE}`);
  console.log("이 창을 닫으면 연결이 끊겨요.");
  checkStatus();
  setTimeout(() => console.log(`ChatGPT(Codex CLI): ${status.codex || "없음"} · Gemini CLI: ${status.gemini || "없음"}`), 4000);
  if (!process.argv.includes("--no-open")) {
    const [cmd, args] = IS_WIN ? ["cmd", ["/c", "start", "", appUrl]] : process.platform === "darwin" ? ["open", [appUrl]] : ["xdg-open", [appUrl]];
    spawn(cmd, args, { windowsHide: true, detached: true, stdio: "ignore" }).on("error", () => {}).unref();
  }
});
server.on("error", (err) => {
  if (err.code === "EADDRINUSE") console.error(`포트 ${PORT} 이 이미 사용 중이에요. 이미 켜져 있다면 ${`http://${HOST}:${PORT}/`} 을 열어 주세요.`);
  else console.error(err);
  process.exit(1);
});
