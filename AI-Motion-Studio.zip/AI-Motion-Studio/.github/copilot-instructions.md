# AI 코딩 도구 지침

이 저장소의 전체 규칙은 `CLAUDE.md`에 있습니다. 작업 전에 반드시 읽으세요.

핵심 요약:
- 순수 HTML/CSS/JS, 빌드 없이 index.html로 동작 (ES 모듈 import 금지, <script> 태그 사용)
- 지식 데이터(툴·단계·용어)는 data/knowledge.js에만
- 사용자 데이터는 localStorage 키 ai-motion-studio:v1, 구조 변경 시 마이그레이션 코드 포함
- 사용자 입력은 esc()로 이스케이프
- 한국어 UI, styles.css의 CSS 변수 사용, 다크 모드 유지
- 기능 로드맵은 docs/PRD.md, 작업 과정은 docs/WORKFLOW.md, 프롬프트 규칙은 docs/PROMPT_RULES.md
