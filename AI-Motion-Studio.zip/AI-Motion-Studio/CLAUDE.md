# CLAUDE.md

이 프로젝트는 AI 모션그래픽 작업 과정을 관리하는 개인용 웹앱 **AI Motion Studio**입니다.

## 먼저 읽을 것
- `docs/PRD.md` — 기능 로드맵 (Phase 1 완료, Phase 2부터 구현)
- `docs/WORKFLOW.md` — 앱이 담고 있는 실제 작업 과정
- `docs/PROMPT_RULES.md` — 프롬프트 빌더가 따르는 규칙

## 기술 규칙
- 순수 HTML/CSS/JS. **빌드 도구·프레임워크 없이** `index.html`을 열면 동작해야 한다 (사용자가 마이그레이션을 요청하기 전까지).
- 스크립트는 `<script>` 태그로 로드한다. 로컬 파일을 ES 모듈로 import 하면 file:// 에서 막히므로 쓰지 않는다.
  - 예외: Claude SDK 는 `data/knowledge.js` 의 `ai.sdkUrl`(CDN, 버전 고정)을 쓸 때만 동적 `import()` 한다 (file:// 에서도 동작 확인).
- 스토리보드 SVG 는 모델이 만든 것이라 `cleanSvg()` 를 거치고 `<img src="data:...">` 로만 표시한다 (innerHTML 로 넣지 않는다).
- 작업 단계(1 기획 ~ 8 편집·AE)는 `knowledge.js` 의 `steps`. 체크리스트를 다시 만들지 않는다 — 진행은 결과물(선택 이미지·채택 영상)로 자동 계산(`stageStatus`).
- 이미지·영상은 IndexedDB(`ai-motion-studio-images`), 프로젝트에는 id 만 둔다. 후보는 `images`/`videos`, 선택은 `pick`/`take`.
- AI 호출은 모두 `app.js` 의 `callClaude()` 를 거친다. 모델·effort·SDK 주소는 `knowledge.js` 의 `ai`, 시스템 프롬프트는 `planning.systemPrompt`.
- **로컬 연결 프로그램** `bridge/server.js` (`start.cmd`): 앱을 http://127.0.0.1:8790 으로 서빙하고
  - `POST /bridge/claude` → `claude -p --json-schema --system-prompt --restricted --strict-mcp-config --tools ""|Read` (구독, 1회 수천 토큰)
  - `POST /bridge/higgsfield` → `claude -p` 에이전트가 Higgsfield 커넥터로 업로드(`bridge/put-mcp.js` 의 put_file) → 일괄 생성 → jobs_wait. 필요 없는 커넥터 도구는 `--disallowedTools` 로 빼서 사용량을 줄인다(70만→10만 토큰). `dryRun` 은 get_cost 로 크레딧 없이 시험.
  - 이 PC 에서 Node fetch 는 upload.higgsfield.ai 에 연결 시간 초과가 잦다 → 업로드(`put-mcp.js`)·결과 다운로드는 curl.exe 를 쓴다(대체 경로로 fetch).
  - 보안: CORS 헤더 없음, `x-ams: 1` 헤더 + 같은 Origin 만 허용, bridge 폴더는 서빙하지 않음.
- 앱 쪽: `callClaude()` 는 연결 프로그램이 있으면 그쪽, 없으면 API 키. 이미지·영상은 `higgsfieldGenerate()` (모델·역할 기본값은 `knowledge.js` 의 `higgsfield`). OpenAI 는 쓰지 않는다.
- API 키는 localStorage `ai-motion-studio:anthropic-key` 에만 둔다. 상태(`ai-motion-studio:v1`)나 백업 파일에 넣지 않는다.
- 툴·단계·용어 같은 **지식 데이터는 `data/knowledge.js`에만** 둔다. UI 코드에 하드코딩 금지.
- 사용자 데이터는 `localStorage` 키 `ai-motion-studio:v1`. 구조를 바꾸면 기존 데이터를 마이그레이션하는 코드를 함께 작성한다.
- 사용자 입력을 HTML에 넣을 때는 반드시 `esc()`로 이스케이프한다.
- UI 문구는 한국어. 색은 `styles.css`의 CSS 변수를 사용하고 다크 모드를 깨뜨리지 않는다.

## 작업 방식
- 새 기능은 작게 나눠서 구현하고, 끝나면 `docs/PRD.md` 체크박스를 갱신한다.
- 변경 후 브라우저 콘솔 에러가 없는지 확인한다.
